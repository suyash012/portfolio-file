import React from 'react'


export default function Home() {
  return (
    <div class="bg-gradient-to-r from-cyan-500 to-blue-500 p-10 text-white">
  <div class="container mx-auto">
    <div class="text-center">
    <h1 class="text-5xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-amber-500 via-yellow-500 to-red-500 mb-8 tracking-wide">
  Hello, My Name is 
</h1>
<h1 class="text-5xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-amber-500 via-yellow-500 to-red-500 mb-8 tracking-wide">
   Suyash Soni
</h1>
      <p class="mt-4">I'm a front-end developer,I write about web development on my blog and regularly speak at various web conferences and meetups. Want to know how I may help your project? Check out my project case studies and resume.</p>
      <a href='https://github.com/suyash012?tab=repositories'><button class="mt-4 bg-white text-blue-500 font-bold py-2 px-4 rounded-full">Hire Me </button></a>
    </div>
    <br></br>
    <div class="bg-white py-12">
  <div class="max-w-4xl mx-auto px-4">
    <div class="text-center mb-12">
      <h2 class="text-3xl font-bold text-black">Skills Overview</h2>
      <p class="mt-4 text-gray-600">I have more than 1 years' experience building rich web applications. Below is a quick overview of my main technical skill sets and tools I use. Want to find out more about my experience? Check out my online resume.</p>
    </div>
    <div class="flex flex-wrap -mx-4">
      <div class="w-full md:w-1/3 px-4 mb-8 md:mb-0">
        <div class="shadow-lg rounded-lg p-6">
          <div class="text-center mb-4">
            <span class="inline-block bg-blue-200 rounded-full p-3 text-blue-600">
             <h2 className='font-bold'>frontend</h2>
            </span>
          </div>
          <h3 class="text-xl font-semibold text-center mb-4">Frontend</h3>
          <ul class="text-gray-600">
            <li>✔ React/Redux</li>
            <li>✔ Javascript</li>
            <li>✔ Node.js</li>
            <li>✔ Webpack/Gulp/Grunt</li>
            <li>✔ HTML/CSS/SASS/Tailwind css</li>
          </ul>
        </div>
      </div>
      <div class="w-full md:w-1/3 px-4 mb-8 md:mb-0">
        <div class="shadow-lg rounded-lg p-6">
          <div class="text-center mb-4">
            <span class="inline-block bg-blue-200 rounded-full p-3 text-blue-600">
            <h2 className='font-bold'>Backend</h2>
            </span>
          </div>
          <h3 class="text-xl font-semibold text-center mb-4">Backend</h3>
          <ul class="text-gray-600">
            <li>✔ Node js</li>
            <li>✔ express js</li>
            <li>✔ PostgresSQL/MySQL</li>
            <li>✔ MongoDB</li>
          </ul>
        </div>
      </div>
      <div class="w-full md:w-1/3 px-4">
        <div class="shadow-lg rounded-lg p-6">
          <div class="text-center mb-4">
            <span class="inline-block bg-blue-200 rounded-full p-3 text-blue-600">
            <h2 className='font-bold'>Others</h2>
            </span>
          </div>
          <h3 class="text-xl font-semibold text-center mb-4">Others</h3>
          <ul class="text-gray-600">
            <li>✔ DSA IN JAVA</li>
            <li>✔ PROBLEM SOLVING</li>
            <li>✔ UX/Wireframing</li>
            <li>✔ Sketch/Balsamiq</li>
            <li>✔ Wordpress/Shopify</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

    </div>       
    </div>
  )
}
