import React from 'react';

const Projects = () => {
  return (
    <div class="container mx-auto py-12 px-4">
    <h1 class="text-4xl font-bold mb-8 text-center">My Projects</h1>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 ">
      <div class="bg-white rounded-lg shadow-md p-6 text-black">
        <h2 class="text-2xl font-bold mb-4">Twitter Clone</h2>
        <p class="mb-4">A web application that mimics the functionality of Twitter, allowing users to post tweets, follow other users, and interact with their posts.</p>
        <a href="https://github.com/suyash012?tab=repositories" class="inline-block bg-blue-500 text-white rounded-md px-4 py-2 hover:bg-blue-600 transition-colors duration-300">View Project</a>
      </div>
      <div class="bg-white rounded-lg shadow-md p-6 text-black">
        <h2 class="text-2xl font-bold mb-4">Weather App</h2>
        <p class="mb-4">A simple web application that displays the current weather conditions and forecast for a user's location or a specified city.</p>
        <a href="https://github.com/suyash012?tab=repositories" class="inline-block bg-blue-500 text-white rounded-md px-4 py-2 hover:bg-blue-600 transition-colors duration-300">View Project</a>
      </div>
      <div class="bg-white rounded-lg shadow-md p-6 text-black">
        <h2 class="text-2xl font-bold mb-4">Chatbot</h2>
        <p class="mb-4">An intelligent chatbot that can understand and respond to user queries, providing relevant information or assistance based on natural language processing.</p>
        <a href="https://github.com/suyash012?tab=repositories" class="inline-block bg-blue-500 text-white rounded-md px-4 py-2 hover:bg-blue-600 transition-colors duration-300">View Project</a>
      </div>
      <div class="bg-white rounded-lg shadow-md p-6 text-black">
        <h2 class="text-2xl font-bold mb-4">OTT Player</h2>
        <p class="mb-4">A web-based video player that allows users to stream and watch movies, TV shows, and other video content from various over-the-top (OTT) platforms.</p>
        <a href="https://github.com/suyash012?tab=repositories" class="inline-block bg-blue-500 text-white rounded-md px-4 py-2 hover:bg-blue-600 transition-colors duration-300">View Project</a>
      </div>
      <div class="bg-white rounded-lg shadow-md p-6 text-black">
        <h2 class="text-2xl font-bold mb-4">Netflix Clone</h2>
        <p class="mb-4">A web application that replicates the user interface and functionality of the popular streaming platform Netflix, allowing users to browse and watch movies and TV shows.</p>
        <a href="https://github.com/suyash012?tab=repositories" class="inline-block bg-blue-500 text-white rounded-md px-4 py-2 hover:bg-blue-600 transition-colors duration-300">View Project</a>
      </div>
    </div>
  </div>
  );
}

export default Projects;