import React from 'react';

const About = () => {
  return (
    <div className="container mx-auto px-4">

    <h1 className="text-4xl font-bold mt-8 mb-4">I'm a Web <span class="text-black">Developer</span></h1>
    <p className="mb-4 text-xl font-bold-sm">I have a solid foundation in web development technologies such as HTML, JavaScript, SQL, CSS, C#, and WordPress. I have completed projects including portfolios, OTT content websites, and more. With my proficiency in editing and selecting templates for web design, coupled with my strong communication and problem-solving skills, I believe I am well-suited for the Web Developer role at your company. I am eager to continue learning and contribute to your team by leveraging my passion for creative problem-solving. I am committed to creating intuitive and efficient websites and am adept at utilizing tools like Tailwind CSS, React, React Router, and have backend experience. I am a quick learner and can effectively implement Tailwind CSS properties to enhance web design.</p>

</div>
  );
}

export default About;