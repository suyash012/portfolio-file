// Header.jsx

import React from 'react';

const Header = () => {
  return (
    <header className=" text-white p-4 ">
        <nav>
          <ul className='flex my-2 mx-2 gap-4 '>
            <li><a href="/home">home</a></li>
            <li><a href="/About">About</a></li>
            <li><a href="/projects">Projects</a></li>
            <li><a href="/contact">Contact</a></li>
          </ul>
        </nav>
    
    </header>
  );
}

export default Header;