import React from 'react';
import { BrowserRouter as Router, Routes,Route } from 'react-router-dom';
import Header from './components/Header';
import About from './components/About';
import Projects from './components/Projects';
import Contact from './components/Contact';
import Home from './components/Home';



function App() {
  return (
    <Router>
      <div className='text-centre bg-gradient-to-r from-cyan-500 to-blue-500 h-screen w-scren'>
        <Header />
        <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/About" element={<About />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;